package com.lszyhb.basicclass;

/**
 * Created by kkk8199 on 11/20/17.
 */

public class ShowAbtAuth extends ShowAbt {

    private Long custId;
    private Integer role;

    public Long getCustId() {
        return custId;
    }

    public void setCustId(Long custId) {
        this.custId = custId;
    }

    public Integer getRole() {
        return role;
    }

    public void setRole(Integer role) {
        this.role = role;
    }

}
