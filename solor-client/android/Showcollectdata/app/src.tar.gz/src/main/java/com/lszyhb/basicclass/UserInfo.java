package com.lszyhb.basicclass;

/**
 * Created by kkk8199 on 11/16/17.
 */

public class UserInfo {
    public String userId;
    public String userName;
    public String pwd;
}