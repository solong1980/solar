package com.lszyhb.update;

/**
 * Created by kkk8199 on 11/22/17.
 */

public class AppVersionDetail {
    public String url;
    public String name;
}
