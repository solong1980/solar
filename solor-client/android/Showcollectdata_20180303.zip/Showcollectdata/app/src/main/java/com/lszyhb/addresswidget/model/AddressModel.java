package com.lszyhb.addresswidget.model;


import java.io.Serializable;

public class AddressModel implements Serializable{
    public int Status;
    public String Msg;
    public AddressDtailsEntity Result;
    public String ServerTime;
}
