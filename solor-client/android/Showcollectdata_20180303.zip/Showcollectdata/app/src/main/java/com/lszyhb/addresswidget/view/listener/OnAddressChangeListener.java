package com.lszyhb.addresswidget.view.listener;

public interface OnAddressChangeListener {
	void onAddressChange(String province, String provinceid, String city,String cityid, String district,String districtid);
}
