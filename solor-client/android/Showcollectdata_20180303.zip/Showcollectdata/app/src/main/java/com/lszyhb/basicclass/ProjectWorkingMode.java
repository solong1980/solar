package com.lszyhb.basicclass;

import com.lszyhb.common.Bitsetconvert;
import com.lszyhb.common.Stringbuild;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.BitSet;

/**
 * Created by kkk8199 on 2/1/18.
 */

public class ProjectWorkingMode extends ShowAbt implements Serializable {
    private Long id;
    private Long projectId;

    private Short h_0=0;
    private Short h_1=0;
    private Short h_2=0;
    private Short h_3=0;
    private Short h_4=0;
    private Short h_5=0;
    private Short h_6=0;
    private Short h_7=0;
    private Short h_8=0;
    private Short h_9=0;
    private Short h_10=0;
    private Short h_11=0;
    private Short h_12=0;
    private Short h_13=0;
    private Short h_14=0;
    private Short h_15=0;
    private Short h_16=0;
    private Short h_17=0;
    private Short h_18=0;
    private Short h_19=0;
    private Short h_20=0;
    private Short h_21=0;
    private Short h_22=0;
    private Short h_23=0;
    private Short h_24=0;
    private Short h_25=0;
    private Short h_26=0;
    private Short h_27=0;
    private Short h_28=0;
    private Short h_29=0;
    private Short h_30=0;
    private Short h_31=0;
    private Short h_32=0;
    private Short h_33=0;
    private Short h_34=0;
    private Short h_35=0;
    private Short h_36=0;
    private Short h_37=0;
    private Short h_38=0;
    private Short h_39=0;
    private Short h_40=0;
    private Short h_41=0;
    private Short h_42=0;
    private Short h_43=0;
    private Short h_44=0;
    private Short h_45=0;
    private Short h_46=0;
    private Short h_47=0;
    private Long createBy;
    private String updateTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Short getH_0() {
        return h_0;
    }

    public void setH_0(Short h_0) {
        this.h_0 = h_0;
    }

    public Short getH_1() {
        return h_1;
    }

    public void setH_1(Short h_1) {
        this.h_1 = h_1;
    }

    public Short getH_2() {
        return h_2;
    }

    public void setH_2(Short h_2) {
        this.h_2 = h_2;
    }

    public Short getH_3() {
        return h_3;
    }

    public void setH_3(Short h_3) {
        this.h_3 = h_3;
    }

    public Short getH_4() {
        return h_4;
    }

    public void setH_4(Short h_4) {
        this.h_4 = h_4;
    }

    public Short getH_5() {
        return h_5;
    }

    public void setH_5(Short h_5) {
        this.h_5 = h_5;
    }

    public Short getH_6() {
        return h_6;
    }

    public void setH_6(Short h_6) {
        this.h_6 = h_6;
    }

    public Short getH_7() {
        return h_7;
    }

    public void setH_7(Short h_7) {
        this.h_7 = h_7;
    }

    public Short getH_8() {
        return h_8;
    }

    public void setH_8(Short h_8) {
        this.h_8 = h_8;
    }

    public Short getH_9() {
        return h_9;
    }

    public void setH_9(Short h_9) {
        this.h_9 = h_9;
    }

    public Short getH_10() {
        return h_10;
    }

    public void setH_10(Short h_10) {
        this.h_10 = h_10;
    }

    public Short getH_11() {
        return h_11;
    }

    public void setH_11(Short h_11) {
        this.h_11 = h_11;
    }

    public Short getH_12() {
        return h_12;
    }

    public void setH_12(Short h_12) {
        this.h_12 = h_12;
    }

    public Short getH_13() {
        return h_13;
    }

    public void setH_13(Short h_13) {
        this.h_13 = h_13;
    }

    public Short getH_14() {
        return h_14;
    }

    public void setH_14(Short h_14) {
        this.h_14 = h_14;
    }

    public Short getH_15() {
        return h_15;
    }

    public void setH_15(Short h_15) {
        this.h_15 = h_15;
    }

    public Short getH_16() {
        return h_16;
    }

    public void setH_16(Short h_16) {
        this.h_16 = h_16;
    }

    public Short getH_17() {
        return h_17;
    }

    public void setH_17(Short h_17) {
        this.h_17 = h_17;
    }

    public Short getH_18() {
        return h_18;
    }

    public void setH_18(Short h_18) {
        this.h_18 = h_18;
    }

    public Short getH_19() {
        return h_19;
    }

    public void setH_19(Short h_19) {
        this.h_19 = h_19;
    }

    public Short getH_20() {
        return h_20;
    }

    public void setH_20(Short h_20) {
        this.h_20 = h_20;
    }

    public Short getH_21() {
        return h_21;
    }

    public void setH_21(Short h_21) {
        this.h_21 = h_21;
    }

    public Short getH_22() {
        return h_22;
    }

    public void setH_22(Short h_22) {
        this.h_22 = h_22;
    }

    public Short getH_23() {
        return h_23;
    }

    public void setH_23(Short h_23) {
        this.h_23 = h_23;
    }

    public Short getH_24() {
        return h_24;
    }

    public void setH_24(Short h_24) {
        this.h_24 = h_24;
    }

    public Short getH_25() {
        return h_25;
    }

    public void setH_25(Short h_25) {
        this.h_25 = h_25;
    }

    public Short getH_26() {
        return h_26;
    }

    public void setH_26(Short h_26) {
        this.h_26 = h_26;
    }

    public Short getH_27() {
        return h_27;
    }

    public void setH_27(Short h_27) {
        this.h_27 = h_27;
    }

    public Short getH_28() {
        return h_28;
    }

    public void setH_28(Short h_28) {
        this.h_28 = h_28;
    }

    public Short getH_29() {
        return h_29;
    }

    public void setH_29(Short h_29) {
        this.h_29 = h_29;
    }

    public Short getH_30() {
        return h_30;
    }

    public void setH_30(Short h_30) {
        this.h_30 = h_30;
    }

    public Short getH_31() {
        return h_31;
    }

    public void setH_31(Short h_31) {
        this.h_31 = h_31;
    }

    public Short getH_32() {
        return h_32;
    }

    public void setH_32(Short h_32) {
        this.h_32 = h_32;
    }

    public Short getH_33() {
        return h_33;
    }

    public void setH_33(Short h_33) {
        this.h_33 = h_33;
    }

    public Short getH_34() {
        return h_34;
    }

    public void setH_34(Short h_34) {
        this.h_34 = h_34;
    }

    public Short getH_35() {
        return h_35;
    }

    public void setH_35(Short h_35) {
        this.h_35 = h_35;
    }

    public Short getH_36() {
        return h_36;
    }

    public void setH_36(Short h_36) {
        this.h_36 = h_36;
    }

    public Short getH_37() {
        return h_37;
    }

    public void setH_37(Short h_37) {
        this.h_37 = h_37;
    }

    public Short getH_38() {
        return h_38;
    }

    public void setH_38(Short h_38) {
        this.h_38 = h_38;
    }

    public Short getH_39() {
        return h_39;
    }

    public void setH_39(Short h_39) {
        this.h_39 = h_39;
    }

    public Short getH_40() {
        return h_40;
    }

    public void setH_40(Short h_40) {
        this.h_40 = h_40;
    }

    public Short getH_41() {
        return h_41;
    }

    public void setH_41(Short h_41) {
        this.h_41 = h_41;
    }

    public Short getH_42() {
        return h_42;
    }

    public void setH_42(Short h_42) {
        this.h_42 = h_42;
    }

    public Short getH_43() {
        return h_43;
    }

    public void setH_43(Short h_43) {
        this.h_43 = h_43;
    }

    public Short getH_44() {
        return h_44;
    }

    public void setH_44(Short h_44) {
        this.h_44 = h_44;
    }

    public Short getH_45() {
        return h_45;
    }

    public void setH_45(Short h_45) {
        this.h_45 = h_45;
    }

    public Short getH_46() {
        return h_46;
    }

    public void setH_46(Short h_46) {
        this.h_46 = h_46;
    }

    public Short getH_47() {
        return h_47;
    }

    public void setH_47(Short h_47) {
        this.h_47 = h_47;
    }

    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String buildMmcMsg() {
        CharSequence[] hs = new CharSequence[48];

    /*    BitSet bitSet = new BitSet(48);
        bitSet.set(1);
        byte[] byteArray = Bitsetconvert.bitSet2ByteArray(bitSet);*/

        for (int i = 0; i < 48; i++) {
            Method method;
            try {
                method = ProjectWorkingMode.class.getMethod("getH_" + i);
                Object v = method.invoke(this);
                hs[i] = v.toString();
            } catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException
                    | InvocationTargetException e1) {
                throw new RuntimeException(e1.getMessage());
            }
        }
        return Stringbuild.join(",", hs);
    }

}
